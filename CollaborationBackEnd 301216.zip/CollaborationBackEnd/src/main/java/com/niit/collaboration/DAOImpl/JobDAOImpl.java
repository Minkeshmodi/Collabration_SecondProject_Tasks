package com.niit.collaboration.DAOImpl;



public class JobDAOImpl {

	
}
