package com.niit.collaboration.DAOImpl;

import java.util.List;
import org.hibernate.Session;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.niit.collaboration.DAO.UserDAO;
import com.niit.collaboration.model.User;
@Repository("UserDAO")
public class UserDAOImpl implements UserDAO {

	@Autowired
	private SessionFactory sessionFactory;
	public  UserDAOImpl(SessionFactory sessionFactory){
		this.sessionFactory = sessionFactory;
	}
	 @Transactional
	public User authenticate(User user) {
		Session session=sessionFactory.openSession();
		Query query=(Query) session.createQuery(
		"from User where username=?  and password=?");
		//select * from User where username='smith' and password='123'
		((org.hibernate.Query) query).setString(0, user.getUsername());
		((org.hibernate.Query) query).setString(1, user.getPassword());
		User validUser=(User)((org.hibernate.Query) query).uniqueResult();
		session.close();
		return validUser;
		
	}

	 @Transactional
	public List<User> list() {
		 String hql = "from User";
		 Query query = (Query) sessionFactory.getCurrentSession().createQuery(hql);
		 
		
		return null;
	}

	 @Transactional
	public void updateUser(User user) {
		 Session session=sessionFactory.openSession();
			User existingUser=(User)session.get(User.class, user.getId());
			
			existingUser.setOnline(user.isOnline()); 
			
			session.update(existingUser);
			session.flush();
			session.close();
		
		
	}

     @Transactional
	public boolean save(User user) {
     try{
    	 sessionFactory.getCurrentSession().save(user); 
     }catch(Exception e){
    	 return false;
     }
		return true;
	}

     @Transactional
	public User get(String id) {
		sessionFactory.getCurrentSession().get(id,User.class);
		return null;
	}

}
