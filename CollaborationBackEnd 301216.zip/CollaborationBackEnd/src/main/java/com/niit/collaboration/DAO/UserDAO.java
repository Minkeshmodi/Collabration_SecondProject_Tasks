package com.niit.collaboration.DAO;

import java.util.List;

import com.niit.collaboration.model.User;

public interface UserDAO {

   public 	User authenticate(User user);
   public List<User> list();
	public void updateUser(User user);
	public boolean save(User user);
	public User get(String id);
	
}
