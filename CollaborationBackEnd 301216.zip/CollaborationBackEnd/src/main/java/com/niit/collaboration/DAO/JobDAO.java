package com.niit.collaboration.DAO;





public interface JobDAO {
	
	
}
