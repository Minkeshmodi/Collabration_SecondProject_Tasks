package com.niit.collaboration.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.niit.collaboration.model.Error;
import com.niit.collaboration.DAO.UserDAO;
import com.niit.collaboration.model.User;

@RestController
public class UserController {
	
	@Autowired
	private UserDAO userDAO;
	
	@RequestMapping(value="/login",method=RequestMethod.POST)
	public ResponseEntity<?> login(@RequestBody User user){
		
		User validUser=userDAO.authenticate(user);
		if(validUser==null){
			Error error=new Error(1,"Username and password doesnt exists...");
			return new ResponseEntity<Error>(error,HttpStatus.UNAUTHORIZED); 
		}
		else{
			validUser.setOnline(true);
			userDAO.updateUser(validUser);
			return new ResponseEntity<User>(validUser,HttpStatus.OK);
		}

	}
}
