package com.niit.backend.dao;

import java.util.List;

import com.niit.backend.model.User;

public interface UserDao {
	
	
public 	User authenticate(User user);
public User updateUser(int userid, User user);
public User registerUser(User user);
void deleteUser(int id);
User getUserById(int userid);
List<User> getAllUsers();

}
