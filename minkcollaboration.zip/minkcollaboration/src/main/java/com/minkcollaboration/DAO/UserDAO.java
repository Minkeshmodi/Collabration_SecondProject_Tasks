package com.minkcollaboration.DAO;

public interface UserDAO {
	

}
