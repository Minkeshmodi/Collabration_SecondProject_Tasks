package com.minkcollaboration.DAOimpl;

public class UserDAOIMPL {

}
