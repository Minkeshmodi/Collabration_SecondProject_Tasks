package com.minkcollaboration.model;

public class User {
	
	

}
