var app = angular.module("myApp2",['ngRoute']);

app.config(function($routeProvider){
	
	$routeProvider
	
	.when('/',{
		
		templateUrl : 'Ex2/view/home.html',
		controller : 'Homecontroller'
	})
	
	.when('/job',{
		
		templateUrl : 'Ex2/view/job.html',
		controller : 'Jobcontroller'
	})
	
	.when('/blog',{
		templateUrl : 'Ex2/view/blog.html',
		controller : 'Blogcontroller'
	})
	
	.when('/friend',{
		templateUrl : 'Ex2/view/friend.html',
		controller : 'Friendcontroller'
	})
	
	.otherwise({redirectTo:'/'})
	
});