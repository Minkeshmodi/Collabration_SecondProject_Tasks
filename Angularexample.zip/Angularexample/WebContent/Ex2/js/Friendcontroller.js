app.controller("Friendcontroller",function($scope){
	
	$scope.message = "welcome to friend controller"
	
});

