app.controller("Jobcontroller",function($scope){
	$scope.message = "Message from the controller"
});

