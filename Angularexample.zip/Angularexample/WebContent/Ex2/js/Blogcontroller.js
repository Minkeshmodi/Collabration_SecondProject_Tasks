app.controller("Blogcontroller",function($scope){
	
	$scope.message = "Message to the blog"
	
	
});



