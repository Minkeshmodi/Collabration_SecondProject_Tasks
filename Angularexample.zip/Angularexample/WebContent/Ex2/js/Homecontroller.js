app.controller('Homecontroller',function($scope)
{
	$scope.message = "Message from home controller"

});