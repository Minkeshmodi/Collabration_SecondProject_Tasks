

var app = angular.module("mymodule",['ngRoute']);

app.config(function($routeProvider){
	
	$routeProvider
	
	.when('/',{
		
		templateUrl : 'Ex1/view/home.html'
		
	})
	
	.when('/job',{
		
		templateUrl : 'Ex1/view/job.html'
	})
	
	.when('/blog',{
		templateUrl : 'Ex1/view/blog.html'
	})
	
	.when('/friend',{
		templateUrl : 'Ex1/view/friend.html'
	})
	
	.otherwise({redirectTo:'/'})
	
});