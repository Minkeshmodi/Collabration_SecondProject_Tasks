 
var myApp = angular.module("myModule",[]);

myApp.controller("mycontroller",function($scope){
	$scope.message = "Angularjs tutorial ";
})

