package com.niit.backend.dao;

import com.niit.backend.model.User;

public interface UserDao {
	
public 	User authenticate(User user);
void updateUser(User user);

}
