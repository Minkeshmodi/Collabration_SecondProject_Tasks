package com.niit.backend.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.niit.backend.model.Error;
import com.niit.backend.dao.UserDao;
import com.niit.backend.model.User;

@RestController
public class UserController {

	
	@Autowired
	private UserDao userDao;
	
	
	
	@RequestMapping(value="/login",method=RequestMethod.POST)
	public ResponseEntity<?> login(@RequestBody User user){
		
		User validUser=userDao.authenticate(user);
		if(validUser==null){
			Error error=new Error(1,"Username and password doesnt exists...");
			return new ResponseEntity<Error>(error,HttpStatus.UNAUTHORIZED); 
		}
		else{
			validUser.setOnline(true);
			userDao.updateUser(validUser); 
			return new ResponseEntity<User>(validUser,HttpStatus.OK);
		}
	}

}
